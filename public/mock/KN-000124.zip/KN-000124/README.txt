Gói bằng chứng mẫu cho chế độ mock. Gói thật do máy chủ tạo (API-136).
